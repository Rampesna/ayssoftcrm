<?php $__env->startSection('title', 'Anasayfa'); ?>
<?php (setlocale(LC_ALL, 'tr_TR.UTF-8')); ?>

<?php $__env->startSection('content'); ?>

    <div class="row">

        <div class="col-xl-12">

            Anasayfa

        </div>

    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-styles'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\talha\PhpstormProjects\ayssoftcrm\resources\views/pages/index.blade.php ENDPATH**/ ?>