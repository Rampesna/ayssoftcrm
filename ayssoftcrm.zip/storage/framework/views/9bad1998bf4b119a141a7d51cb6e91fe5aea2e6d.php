<div class="d-flex flex-column flex-row-fluid" id="kt_wrapper">
    <div class="content d-flex flex-column flex-column-fluid mt-20" id="kt_content">

        <div class="container-fluid" style="margin-top: -50px">

            <?php echo $__env->yieldContent('content'); ?>

        </div>

    </div>
    <!--end::Content-->
    <!--begin::Footer-->
<?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<!--end::Footer-->
    
</div>
<?php /**PATH C:\Users\talha\PhpstormProjects\ayssoftcrm\resources\views/layouts/tvnavbar.blade.php ENDPATH**/ ?>