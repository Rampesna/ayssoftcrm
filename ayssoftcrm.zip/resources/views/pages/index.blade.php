@extends('layouts.master')
@section('title', 'Anasayfa')
@php(setlocale(LC_ALL, 'tr_TR.UTF-8'))

@section('content')

    <div class="row">

        <div class="col-xl-12">

            Anasayfa

        </div>

    </div>

@endsection

@section('page-styles')

@stop

@section('page-script')

@stop
