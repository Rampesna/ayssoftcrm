<?php


namespace App\Http\Helpers;

use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Http;

abstract class AysApiBase
{
    public function callApi($url, $method, $headers = [], $params = [])
    {
        return Http::withHeaders($headers)->$method($url, $params);
    }

    public function LoginApi($baseUrl)
    {
        $endpoint = 'Account/Login';
        $headers = [
            'Content-Type: application/json'
        ];
        $params = [
            'Email' => env('AYS_API_USER'),
            'Password' => env('AYS_API_PASSWORD')
        ];
        Cookie::queue('accessToken', $this->callApi($baseUrl . $endpoint, 'post', $headers, $params)['accessToken'], 719);
    }
}
