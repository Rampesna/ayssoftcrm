<?php


namespace App\Http\Helpers;


use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Http;

class AysApi extends AysApiBase
{
    public $baseUrl;
    public $endpoint;
    public $accessToken;

    public function __construct()
    {
        $this->baseUrl = env('AYS_API_BASE_URL', '192.168.2.200:5051/api/');
        $tokenControl = Cookie::get('accessToken');
        if (is_null($tokenControl)) {
            $this->LoginApi($this->baseUrl);
            $this->accessToken = Cookie::get('accessToken');
        } else {
            $this->accessToken = Cookie::get('accessToken');
        }
    }

    public function TvScreenGetJobList()
    {
        $endpoint = "TvScreen/GetJobList";
        $headers = [
            'Authorization' => 'Bearer ' . $this->accessToken,
        ];
        return $this->callApi($this->baseUrl . $endpoint, 'get', $headers);
    }

    public function TvScreenGetStaffStatusList()
    {
        $endpoint = "TvScreen/GetStaffStatusList";
        $headers = [
            'Authorization' => 'Bearer ' . $this->accessToken,
        ];
        return $this->callApi($this->baseUrl . $endpoint, 'get', $headers);
    }

    public function TvScreenGetStaffStarList()
    {
        $endpoint = "TvScreen/GetStaffStarList";
        $headers = [
            'Authorization' => 'Bearer ' . $this->accessToken,
        ];
        return $this->callApi($this->baseUrl . $endpoint, 'get', $headers);
    }

}
