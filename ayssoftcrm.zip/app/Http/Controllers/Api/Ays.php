<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Helpers\AysApi;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\View;

class Ays extends Controller
{

    public function Section1()
    {
        $api = new AysApi;
        $tvScreenJobList = $api->TvScreenGetJobList();
        $responseBody = $tvScreenJobList['response'];
        $totalNewJobs = 0;
        foreach ($responseBody as $data) {
            if ($data['durum'] == "True") {
                $totalNewJobs += $data['sayi'];
            }
        }
        $returnArray = [
            'responseBody' => $responseBody,
            'totalNewJobs' => $totalNewJobs
        ];

        return response()->json($returnArray, 200);
    }

    public function Section2()
    {
        $api = new AysApi();
        $response1 = $api->TvScreenGetStaffStatusList();
        $response2 = $api->TvScreenGetStaffStarList();

        $blackTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];
        $greenTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];
        $blueTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];
        $redTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];
        $purpleTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];
        $brownTeam = [
            "users" => 0,
            "absentees" => 0,
            "arrived" => 0,
            "in_job" => 0,
            "not_job" => 0,
            "total_job" => 0,
            "support" => 0
        ];

        $totalUserCount = 0;
        $needBreakCount = 0;
        $foodBreakCount = 0;
        $otherBreakCount = 0;
        $activeUserCount = 0;
        $absenteeUserCount = 0;

        $users = [];

        foreach ($response1['response'] as $user) {

            $users[] = $user;

            $totalUserCount += 1;

            if ($user['durumKodu'] == 2) {
                $needBreakCount += 1;
            } else if ($user['durumKodu'] == 3) {
                $foodBreakCount += 1;
            } else if ($user['durumKodu'] == 8 || $user['durumKodu'] == 4 || $user['durumKodu'] == 5) {
                $otherBreakCount += 1;
            }

            if ($user['durumKodu'] != 6) {
                $activeUserCount += 1;
            } else {
                $absenteeUserCount += 1;
            }

            if ($user['takimKodu'] == 1) {
                $blackTeam["users"] += 1;
                $blackTeam["total_job"] += $user['yapilanIs'];
                if ($user['durumKodu'] == 6) {
                    $blackTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $blackTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $blackTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $blackTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $blackTeam["support"] += 1;
                }
            } else if ($user['takimKodu'] == 2) {
                $greenTeam["users"] += 1;
                $greenTeam["total_job"] += $user['yapilanIs'];
                if ($user['durumKodu'] == 6) {
                    $greenTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $greenTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $greenTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $greenTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $greenTeam["support"] += 1;
                }

            } else if ($user['takimKodu'] == 3) {
                $blueTeam["users"] += 1;
                $blueTeam["total_job"] += $user['yapilanIs'];
                if ($user['durumKodu'] == 6) {
                    $blueTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $blueTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $blueTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $blueTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $blueTeam["support"] += 1;
                }
            } else if ($user['takimKodu'] == 4) {
                $redTeam["users"] += 1;
                $redTeam["total_job"] += $user['yapilanIs'];
                if ($user['durumKodu'] == 6) {
                    $redTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $redTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $redTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $redTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $redTeam["support"] += 1;
                }
            } else if ($user['takimKodu'] == 5) {
                $purpleTeam["users"] += 1;
                $purpleTeam["total_job"] += $user['yapilanIs'];
                if ($user['durumKodu'] == 6) {
                    $purpleTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $purpleTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $purpleTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $purpleTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $purpleTeam["support"] += 1;
                }
            } else if ($user['takimKodu'] == 9) {
                $brownTeam["users"] += 1;
                $brownTeam["total_job"] += $user['pazarlamaIsler'];
                if ($user['durumKodu'] == 6) {
                    $brownTeam["absentees"] += 1;
                } else if ($user['durumKodu'] != 6) {
                    $brownTeam["arrived"] += 1;
                }
                if ($user['durumKodu'] == 1) {
                    $brownTeam["in_job"] += 1;
                } else if ($user['durumKodu'] == 2 || $user['durumKodu'] == 3) {
                    $brownTeam["not_job"] += 1;
                } else if ($user['durumKodu'] == 8) {
                    $brownTeam["support"] += 1;
                }

            }
        }

        $allBreakCount = $needBreakCount + $foodBreakCount + $otherBreakCount;

        $returnArray = [
            'blackTeam' => $blackTeam,
            'greenTeam' => $greenTeam,
            'blueTeam' => $blueTeam,
            'redTeam' => $redTeam,
            'purpleTeam' => $purpleTeam,
            'brownTeam' => $brownTeam,
            'totalUserCount' => $totalUserCount,
            'needBreakCount' => $needBreakCount,
            'foodBreakCount' => $foodBreakCount,
            'otherBreakCount' => $otherBreakCount,
            'allBreakCount' => $allBreakCount,
            'activeUserCount' => $activeUserCount,
            'absenteeUserCount' => $absenteeUserCount,
            'users' => $users,
            'starList' => $response2['response']
        ];

        return response()->json($returnArray, 200);

    }

}
